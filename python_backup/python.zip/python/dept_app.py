import deptMain

#main
if __name__ == '__main__' :
     deptMain.main()
